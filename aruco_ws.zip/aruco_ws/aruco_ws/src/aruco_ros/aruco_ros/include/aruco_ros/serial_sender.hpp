#ifndef ARUCO_ROS_SERIAL_SENDER_HPP
#define ARUCO_ROS_SERIAL_SENDER_HPP

#include <string>
#include <vector>
#include <cstdint>
#include <opencv2/core.hpp>
#include <tf2/LinearMath/Quaternion.h>
#include "aruco_ros/udp_sender.hpp" // For TagData definition
#include <thread>
#include <mutex>
#include <condition_variable>
#include <queue>
#include <atomic>

namespace aruco_ros
{

class SerialSender
{
public:
    SerialSender(const std::string& port, int baud_rate);
    ~SerialSender();

    void sendData(const std::vector<TagData>& tags, uint32_t seq, uint64_t timestamp_ns);

private:
    void senderLoop();

    int fd_;
    bool initialized_;

    std::thread sender_thread_;
    std::mutex mutex_;
    std::condition_variable cv_;
    std::queue<std::string> queue_;
    std::atomic<bool> running_;
};

} // namespace aruco_ros

#endif // ARUCO_ROS_SERIAL_SENDER_HPP
